This folder contains an example page in various formats for testing
the conversions from one format to another.

In order to update the contents you typically make changes to
"wiki.txt" and run update.sh to update the other files.

MAKE SURE THE UPDATES ARE CORRECT by inspecting the diffs very
carefully!
